import * as allfunctions from "./modules/functions.js";
import * as burgerMenu from "./modules/burger.js";

allfunctions.testWebP();
